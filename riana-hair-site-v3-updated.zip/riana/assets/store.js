/* Shared store logic */
(function () {
  "use strict";

  var SITE = window.SITE || {};
  var PRODUCTS = window.PRODUCTS || [];
  var COLLECTIONS = window.COLLECTIONS || [];
  var money = function (n) { return (SITE.currency || "R") + Number(n).toLocaleString("en-ZA"); };

  var cart = {};
  try { cart = JSON.parse(localStorage.getItem("riana_cart") || "{}"); } catch (e) { cart = {}; }
  var notes = "";
  try { notes = localStorage.getItem("riana_notes") || ""; } catch (e) { notes = ""; }

  function saveCart() { try { localStorage.setItem("riana_cart", JSON.stringify(cart)); } catch (e) {} }
  function saveNotes() { try { localStorage.setItem("riana_notes", notes); } catch (e) {} }

  function collectionFor(cat) { return COLLECTIONS.find(function (c) { return c.slug === cat; }); }

  // Real photo when the product has one, otherwise fall back to the CSS placeholder shape.
  function visual(p) {
    if (p.img) {
      return '<img class="product-photo" src="' + p.img + '" alt="' + p.name + '" loading="lazy">';
    }
    return '<div class="hair-shape ' + (p.type || '') + '" aria-hidden="true"></div>';
  }

  // Star rating markup, e.g. 4.8 -> 4 full + 1 partial + empty outlines
  function starSvg(fillId, pct) {
    return '<span class="star" aria-hidden="true"><svg width="13" height="13" viewBox="0 0 24 24"><defs><clipPath id="' + fillId + '"><rect x="0" y="0" width="' + (24 * pct) + '" height="24"/></clipPath></defs>'
      + '<path fill="#e7d3d3" d="M12 2l2.9 6.4 6.9.7-5.2 4.7 1.5 6.9L12 17l-6.1 3.7 1.5-6.9-5.2-4.7 6.9-.7z"/>'
      + '<path fill="#c98f9c" clip-path="url(#' + fillId + ')" d="M12 2l2.9 6.4 6.9.7-5.2 4.7 1.5 6.9L12 17l-6.1 3.7 1.5-6.9-5.2-4.7 6.9-.7z"/>'
      + '</svg></span>';
  }
  function stars(rating, reviews, opts) {
    opts = opts || {};
    if (!rating) return '';
    var out = '<div class="rating' + (opts.big ? ' rating-lg' : '') + '">';
    for (var i = 0; i < 5; i++) {
      var pct = Math.max(0, Math.min(1, rating - i));
      out += starSvg('star' + Math.round(rating * 10) + '-' + i + Math.floor(Math.random() * 99999), pct);
    }
    out += '<span class="rating-num">' + rating.toFixed(1) + '</span>';
    if (reviews) out += '<span class="rating-count">(' + reviews + ')</span>';
    out += '</div>';
    return out;
  }

  function priceRow(p) {
    if (p.wasPrice && p.wasPrice > p.price) {
      var pct = Math.round((1 - p.price / p.wasPrice) * 100);
      return '<span class="price"><span class="was">' + money(p.wasPrice) + '</span>' + money(p.price) + '<span class="save-pill">−' + pct + '%</span></span>';
    }
    return '<span class="price">' + money(p.price) + '</span>';
  }

  function cartTotalCount() { return Object.values(cart).reduce(function (a,b){return a+b;},0); }
  function cartSubtotal(){var sub=0;Object.keys(cart).forEach(function(id){var p=PRODUCTS.find(function(x){return x.id===id});if(p)sub+=p.price*cart[id]});return sub}

  function addToCart(id, qty){ qty = qty || 1; cart[id] = (cart[id]||0) + qty; saveCart(); }

  function renderProducts(container, list, opts){
    opts = opts || {};
    if(!container) return;
    if(!list.length){ container.innerHTML = '<div class="no-results">No hair styles match this filter yet — check back soon.</div>'; return; }
    container.innerHTML = list.map(function(p){
      var outOfStock = p.inStock===false;
      var badgeClass = outOfStock ? 'badge out' : 'badge';
      var badgeText = outOfStock ? 'Sold out' : p.tag;
      var btn = outOfStock ? '<button class="add" disabled aria-disabled="true">Sold out</button>' : '<button class="add" data-id="'+p.id+'" aria-label="Add '+p.name+' to cart">Add</button>';
      var link = 'product.html?id='+encodeURIComponent(p.id);
      var saleTag = (p.wasPrice && p.wasPrice > p.price) ? '<span class="badge sale">Sale</span>' : '';
      return '<article class="product">'
        + '<a class="product-link" href="'+link+'">'
        + '<div class="product-visual"><span class="'+badgeClass+'">'+badgeText+'</span>'+saleTag+visual(p)+'</div>'
        + '<div class="product-body"><h3>'+p.name+'</h3><div class="meta">'+p.meta+'</div>'+stars(p.rating,p.reviews)+'</div>'
        + '</a>'
        + '<div class="price-row">'+priceRow(p)+btn+'</div>'
        + '</article>';
    }).join('');
  }

  function renderCart(els){
    if(els.cartCount) els.cartCount.textContent = cartTotalCount();
    var ids = Object.keys(cart).filter(function(id){return cart[id]>0});
    if(els.drawerItems){
      if(!ids.length){ els.drawerItems.innerHTML='<div class="empty">Your cart is empty.<br>Find a hair style you love and add it here.</div>'; }
      else {
        els.drawerItems.innerHTML = ids.map(function(id){
          var p = PRODUCTS.find(function(x){return x.id===id}); if(!p) return '';
          var q = cart[id];
          var thumb = p.img ? '<img src="'+p.img+'" alt="" class="thumb-img">' : '<div class="mini"></div>';
          return '<div class="cart-item" data-id="'+id+'"><div class="thumb" aria-hidden="true">'+thumb+'</div><div class="cart-info"><strong>'+p.name+'</strong><span>'+money(p.price)+' each</span><div class="qty"><button class="minus" aria-label="Decrease quantity of '+p.name+'">−</button><b>'+q+'</b><button class="plus" aria-label="Increase quantity of '+p.name+'">+</button></div><button class="remove" aria-label="Remove '+p.name+' from cart">Remove</button></div></div>';
        }).join('');
      }
    }
    var sub = cartSubtotal();
    if(els.subtotal) els.subtotal.textContent = money(sub);
    if(els.freeDelivery){
      var threshold = SITE.freeDeliveryThreshold || 0;
      if(threshold>0 && ids.length){
        var remaining = threshold - sub;
        els.freeDelivery.textContent = remaining>0 ? 'Add '+money(remaining)+' more for free delivery.' : "You've unlocked free delivery! ✓";
        els.freeDelivery.classList.remove('hidden');
      } else { els.freeDelivery.classList.add('hidden'); }
    }
    if(els.checkoutBtn) els.checkoutBtn.disabled = ids.length===0;
  }

  function buildWhatsAppMessage(){
    var lines = ['Hi RIANA Hair! I\'d like to order:'];
    var ids = Object.keys(cart).filter(function(id){return cart[id]>0});
    ids.forEach(function(id){ var p = PRODUCTS.find(function(x){return x.id===id}); if(!p) return; var q = cart[id]; lines.push('- '+p.name+' x'+q+' ('+money(p.price*q)+')'); });
    lines.push('Subtotal: '+money(cartSubtotal()));
    if(notes && notes.trim()) lines.push('Notes: '+notes.trim());
    lines.push(''); lines.push('Please confirm availability and delivery.');
    return lines.join('\n');
  }

  function whatsappHref(text){
    var number = (SITE.whatsappNumber||'').replace(/[^0-9]/g,'');
    return 'https://wa.me/'+number+'?text='+encodeURIComponent(text);
  }

  function careFor(cat){
    if(cat==='humanblend'){
      return { title: 'Caring for your human hair blend', items: [
        'Detangle gently from the ends upward before washing.',
        'Use a moisturising, sulfate-free shampoo and conditioner.',
        'Air-dry on a wig stand where possible.',
        'Always use heat protectant before styling with hot tools.'
      ]};
    }
    return { title: 'Caring for your fibre & synthetic hair', items: [
      'Check the product label before using any heat tools.',
      'Use fibre-safe shampoo and lightweight conditioner only.',
      'Store the unit on a stand or in a satin bag when not worn.',
      'Keep away from direct heat sources and excess friction.'
    ]};
  }

  function renderProductPage(p){
    var col = collectionFor(p.cat) || {};
    document.title = 'RIANA Hair — ' + p.name;

    var crumbCat = document.getElementById('pdCrumbCat');
    if(crumbCat){ crumbCat.textContent = col.name || p.cat; crumbCat.setAttribute('href', col.file || 'riana-hair.html'); }
    var crumbName = document.getElementById('pdCrumbName');
    if(crumbName) crumbName.textContent = p.name;

    var imgWrap = document.getElementById('pdImgWrap');
    if(imgWrap) imgWrap.innerHTML = visual(p);

    var badge = document.getElementById('pdBadge');
    if(badge) badge.textContent = p.tag || '';

    var nameEl = document.getElementById('pdName');
    if(nameEl) nameEl.textContent = p.name;

    var priceEl = document.getElementById('pdPrice');
    if(priceEl) priceEl.innerHTML = priceRow(p);

    var ratingEl = document.getElementById('pdRating');
    if(ratingEl) ratingEl.innerHTML = stars(p.rating, p.reviews, {big:true});

    var stockEl = document.getElementById('pdStock');
    if(stockEl){
      var inStock = p.inStock !== false;
      stockEl.textContent = inStock ? 'In stock — ready to ship' : 'Sold out';
      stockEl.className = inStock ? 'stock-pill' : 'stock-pill out';
    }

    var metaEl = document.getElementById('pdMeta');
    if(metaEl) metaEl.textContent = p.meta || '';

    var descEl = document.getElementById('pdDesc');
    if(descEl) descEl.textContent = p.desc || col.intro || '';

    var featuresEl = document.getElementById('pdFeatures');
    if(featuresEl && p.meta){
      var parts = p.meta.split('•').map(function(s){return s.trim();}).filter(Boolean);
      featuresEl.innerHTML = parts.map(function(f){return '<li>'+f+'</li>';}).join('');
    }

    var collectionLink = document.getElementById('pdCollectionLink');
    if(collectionLink){ collectionLink.textContent = 'View full ' + (col.name||'') + ' collection'; collectionLink.setAttribute('href', col.file || 'riana-hair.html'); }

    var care = careFor(p.cat);
    var careTitle = document.getElementById('pdCareTitle');
    if(careTitle) careTitle.textContent = care.title;
    var careList = document.getElementById('pdCareList');
    if(careList) careList.innerHTML = care.items.map(function(i){return '<li>'+i+'</li>';}).join('');

    var addBtn = document.getElementById('pdAdd');
    if(addBtn){
      addBtn.disabled = p.inStock===false;
      if(p.inStock===false) addBtn.textContent = 'Sold out';
    }

    var askBtn = document.getElementById('pdAsk');
    if(askBtn){
      var msg = 'Hi RIANA Hair! I\'d like to ask about the ' + p.name + ' (' + money(p.price) + ').';
      askBtn.setAttribute('href', whatsappHref(msg));
    }

    return p;
  }

  function initFloatingWhatsApp(){
    if(document.getElementById('waFloat')) return;
    var number = (SITE.whatsappNumber||'').replace(/[^0-9]/g,'');
    if(!number) return;
    var a = document.createElement('a');
    a.id = 'waFloat';
    a.className = 'wa-float';
    a.target = '_blank';
    a.rel = 'noopener';
    a.setAttribute('aria-label','Chat with RIANA Hair on WhatsApp');
    a.href = whatsappHref('Hi RIANA Hair! I have a question about your hair.');
    a.innerHTML = '<svg viewBox="0 0 32 32" width="26" height="26" fill="currentColor" aria-hidden="true"><path d="M16.02 3C9.4 3 4 8.37 4 14.98c0 2.37.65 4.58 1.79 6.48L4 29l7.74-1.73a12.9 12.9 0 0 0 4.28.73h.01c6.62 0 12-5.37 12-11.98C28.03 8.37 22.65 3 16.02 3zm0 21.7h-.01a10.6 10.6 0 0 1-5.42-1.49l-.39-.23-4.6 1.03 1.06-4.5-.25-.46a10.63 10.63 0 0 1-1.65-5.07C4.76 8.94 9.83 4.9 16.02 4.9c2.86 0 5.55 1.12 7.57 3.14a10.6 10.6 0 0 1 3.14 7.55c0 6.19-5.07 9.11-10.71 9.11zm5.86-7.62c-.32-.16-1.9-.94-2.2-1.05-.29-.11-.51-.16-.72.16-.21.32-.83 1.05-1.02 1.26-.19.21-.38.24-.7.08-.32-.16-1.35-.5-2.57-1.6-.95-.85-1.59-1.9-1.78-2.22-.19-.32-.02-.49.14-.65.14-.14.32-.38.48-.56.16-.19.21-.32.32-.54.11-.21.05-.4-.03-.56-.08-.16-.72-1.75-.99-2.4-.26-.62-.52-.54-.72-.55h-.61c-.21 0-.56.08-.85.4-.29.32-1.11 1.09-1.11 2.65 0 1.56 1.14 3.07 1.3 3.28.16.21 2.24 3.44 5.43 4.82.76.33 1.35.53 1.81.68.76.24 1.45.21 2 .13.61-.09 1.9-.78 2.17-1.53.27-.75.27-1.4.19-1.53-.08-.13-.29-.21-.61-.37z"/></svg>';
    document.body.appendChild(a);
  }

  function init(opts){
    opts = opts||{};
    var category = opts.category||null;
    var product = opts.product||null;

    var productsEl = document.getElementById('products');
    var filtersEl = document.getElementById('filters');
    var cartCount = document.getElementById('cartCount');
    var drawerItems = document.getElementById('drawerItems');
    var subtotal = document.getElementById('subtotal');
    var freeDelivery = document.getElementById('freeDelivery');
    var checkoutBtn = document.getElementById('checkout');
    var notesField = document.getElementById('cartNotes');
    var notice = document.getElementById('notice');
    var drawer = document.getElementById('drawer');
    var overlay = document.getElementById('overlay');
    var openCartBtn = document.getElementById('openCart');
    var closeCartBtn = document.getElementById('closeCart');
    var header = document.getElementById('header');
    var menuBtn = document.getElementById('menuBtn');
    var mobileLinks = document.getElementById('mobileLinks');
    var searchEl = document.getElementById('shopSearch');
    var sortEl = document.getElementById('shopSort');
    var els = {cartCount:cartCount, drawerItems:drawerItems, subtotal:subtotal, freeDelivery:freeDelivery, checkoutBtn:checkoutBtn};
    var currentFilter = 'all';

    function sortList(list, mode){
      var arr = list.slice();
      if(mode==='price-asc') arr.sort(function(a,b){return a.price-b.price});
      else if(mode==='price-desc') arr.sort(function(a,b){return b.price-a.price});
      else if(mode==='rating') arr.sort(function(a,b){return (b.rating||0)-(a.rating||0)});
      return arr;
    }

    function showProducts(filter){
      if(filter) currentFilter = filter;
      var list = !currentFilter||currentFilter==='all' ? PRODUCTS : PRODUCTS.filter(function(p){return p.cat===currentFilter});
      var q = searchEl ? searchEl.value.trim().toLowerCase() : '';
      if(q){ list = list.filter(function(p){ return (p.name+' '+p.meta+' '+(p.tag||'')).toLowerCase().indexOf(q)>-1; }); }
      if(sortEl && sortEl.value) list = sortList(list, sortEl.value);
      renderProducts(productsEl, list);
    }

    if(product){
      renderProductPage(product);
      var relatedEl = document.getElementById('related');
      var relatedSection = document.getElementById('relatedSection');
      if(relatedEl){
        var related = PRODUCTS.filter(function(p){ return p.cat===product.cat && p.id!==product.id; }).slice(0,4);
        if(related.length===0){
          if(relatedSection) relatedSection.classList.add('hidden');
        } else {
          renderProducts(relatedEl, related);
        }
      }
    } else if(category){
      showProducts(category);
    } else if(filtersEl){
      showProducts('all');
      filtersEl.addEventListener('click', function(e){
        var b = e.target.closest('.filter'); if(!b) return;
        filtersEl.querySelectorAll('.filter').forEach(function(x){ x.classList.remove('active'); x.removeAttribute('aria-current'); });
        b.classList.add('active'); b.setAttribute('aria-current','true');
        showProducts(b.dataset.filter);
        var shop = document.getElementById('shop'); if(shop) shop.scrollIntoView({behavior:'smooth'});
      });
    } else if(productsEl){
      showProducts('all');
    }

    if(searchEl) searchEl.addEventListener('input', function(){ showProducts(); });
    if(sortEl) sortEl.addEventListener('change', function(){ showProducts(); });

    if(notesField){ notesField.value = notes; notesField.addEventListener('input', function(){ notes = notesField.value; saveNotes(); }); }

    renderCart(els);

    // Delegated add-to-cart for listing/related product cards
    document.addEventListener('click', function(e){
      var b = e.target.closest('.add');
      if(!b || b.disabled) return;
      e.preventDefault();
      addToCart(b.dataset.id, 1);
      renderCart(els);
      b.textContent = 'Added ✓'; b.classList.add('added');
      setTimeout(function(){ b.textContent = 'Add'; b.classList.remove('added'); }, 900);
    });

    // Product detail page: quantity stepper + add-to-cart
    if(product){
      var qtyVal = document.getElementById('pdQtyVal');
      var qtyMinus = document.getElementById('pdQtyMinus');
      var qtyPlus = document.getElementById('pdQtyPlus');
      var addBtn = document.getElementById('pdAdd');
      var qty = 1;
      function renderQty(){ if(qtyVal) qtyVal.textContent = qty; }
      renderQty();
      if(qtyMinus) qtyMinus.addEventListener('click', function(){ qty = Math.max(1, qty-1); renderQty(); });
      if(qtyPlus) qtyPlus.addEventListener('click', function(){ qty = Math.min(10, qty+1); renderQty(); });
      if(addBtn) addBtn.addEventListener('click', function(){
        if(addBtn.disabled) return;
        addToCart(product.id, qty);
        renderCart(els);
        addBtn.textContent = 'Added to cart ✓'; addBtn.classList.add('added');
        setTimeout(function(){ addBtn.textContent = 'Add to cart — ' + money(product.price*1); addBtn.classList.remove('added'); }, 1200);
        openDrawer();
      });
      if(addBtn && addBtn.disabled===false) addBtn.textContent = 'Add to cart — ' + money(product.price);
    }

    if(drawerItems){
      drawerItems.addEventListener('click', function(e){
        var row = e.target.closest('.cart-item'); if(!row) return;
        var id = row.dataset.id;
        if(e.target.classList.contains('plus')) cart[id]++;
        if(e.target.classList.contains('minus')) cart[id] = Math.max(0, cart[id]-1);
        if(e.target.classList.contains('remove')) cart[id]=0;
        saveCart(); renderCart(els);
      });
    }

    function openDrawer(){ if(!drawer) return; drawer.classList.add('show'); overlay.classList.add('show'); drawer.setAttribute('aria-hidden','false'); if(notice) notice.classList.remove('show'); }
    function closeDrawer(){ if(!drawer) return; drawer.classList.remove('show'); overlay.classList.remove('show'); drawer.setAttribute('aria-hidden','true'); }
    if(openCartBtn) openCartBtn.addEventListener('click', openDrawer);
    if(closeCartBtn) closeCartBtn.addEventListener('click', closeDrawer);
    if(overlay) overlay.addEventListener('click', closeDrawer);
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeDrawer(); });

    if(checkoutBtn){ checkoutBtn.addEventListener('click', function(){ if(cartTotalCount()===0) return; window.open(whatsappHref(buildWhatsAppMessage()), '_blank', 'noopener'); if(notice) notice.classList.add('show'); }); }

    window.addEventListener('storage', function(e){ if(e.key==='riana_cart'){ try{ cart = JSON.parse(e.newValue||'{}'); } catch(err){ cart = {}; } renderCart(els); } });

    if(menuBtn && mobileLinks){
      menuBtn.addEventListener('click', function(){ var open = mobileLinks.classList.toggle('show'); menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false'); });
      mobileLinks.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', function(){ mobileLinks.classList.remove('show'); menuBtn.setAttribute('aria-expanded','false'); }); });
    }

    if(header){ var onScroll = function(){ header.classList.toggle('scrolled', window.scrollY > 20); }; window.addEventListener('scroll', onScroll, {passive:true}); onScroll(); }

    // FAQ accordion
    document.querySelectorAll('.faq-item').forEach(function(item){
      var q = item.querySelector('.faq-q');
      if(!q) return;
      q.addEventListener('click', function(){
        var isOpen = item.classList.contains('open');
        document.querySelectorAll('.faq-item.open').forEach(function(o){ if(o!==item){ o.classList.remove('open'); o.querySelector('.faq-q').setAttribute('aria-expanded','false'); } });
        item.classList.toggle('open', !isOpen);
        q.setAttribute('aria-expanded', (!isOpen).toString());
      });
    });

    // Newsletter / WhatsApp community form
    var joinForm = document.getElementById('joinForm');
    if(joinForm){
      joinForm.addEventListener('submit', function(e){
        e.preventDefault();
        var input = document.getElementById('joinInput');
        var val = input ? input.value.trim() : '';
        var msg = document.getElementById('joinMsg');
        if(!val){ return; }
        if(msg){ msg.textContent = "You're on the list! We'll be in touch with deals & drops."; msg.classList.add('show'); }
        joinForm.reset();
      });
    }

    initFloatingWhatsApp();
  }

  function getProductFromQuery(){
    var params = new URLSearchParams(window.location.search);
    var id = params.get('id');
    if(!id) return null;
    return PRODUCTS.find(function(p){ return p.id === id; }) || null;
  }

  window.RianaStore = { init: init, money: money, getProductFromQuery: getProductFromQuery, renderProducts: renderProducts };
})();
