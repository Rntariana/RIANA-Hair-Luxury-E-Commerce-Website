window.SITE = {
  name: "RIANA Hair",
  whatsappNumber: "27000000000",
  email: "hello@rianahair.co.za",
  city: "Johannesburg, South Africa",
  instagram: "",
  tiktok: "",
  facebook: "",
  currency: "R",
  freeDeliveryThreshold: 1000
};
