window.COLLECTIONS = [
  { slug: "bodywave", file: "bodywave.html", number: "01", name: "Bodywave", tagline: "Soft movement • everyday glam", intro: "Bodywave styles give you soft movement and an easy everyday finish.", img: "assets/images/bodywave-black-glossy.jpg" },
  { slug: "crimps", file: "crimps.html", number: "02", name: "Crimps", tagline: "Textured • playful • bold", intro: "Crimps bring texture and personality when you want a more statement look.", img: "assets/images/crimps-tight-curl.jpg" },
  { slug: "futura", file: "futura.html", number: "03", name: "Futura Fibre", tagline: "Affordable • heat-resistant options", intro: "Futura fibre gives you an affordable styling option. Always follow the heat label for the exact piece.", img: "assets/images/futura-bangs.jpg" },
  { slug: "headband", file: "headband.html", number: "04", name: "Headband Wigs", tagline: "Quick wear • no fuss", intro: "Headband wigs are made for easy everyday wear with no complicated install.", img: "assets/images/headband-curly.jpg" },
  { slug: "humanblend", file: "humanblend.html", number: "05", name: "Human Hair Blends", tagline: "Natural feel • accessible price", intro: "Human hair blends combine a natural-looking feel with a more accessible price point.", img: "assets/images/humanblend-sleek-straight.jpg" },
  { slug: "straight", file: "straight.html", number: "06", name: "Straight Wigs", tagline: "Sleek • clean • classic", intro: "Straight wigs keep the look sleek, simple and timeless.", img: "assets/images/straight-sleek-long.jpg" },
  { slug: "frontal", file: "frontal.html", number: "07", name: "Full Frontals", tagline: "Install-ready options", intro: "Full frontals give you more styling flexibility for your install.", img: "assets/images/humanblend-sleek-straight.jpg" },
  { slug: "glueless", file: "glueless.html", number: "08", name: "Glueless Wigs", tagline: "Easy wear • beginner-friendly", intro: "Glueless wigs are designed for easy wear when you want a quick, beginner-friendly look.", img: "assets/images/glueless-glossy-waves.jpg" },
  { slug: "dupe", file: "dupe.html", number: "09", name: "Latisha Dupe", tagline: "Inspired style • budget-friendly", intro: "A budget-friendly inspired style for customers who want the look without the higher price tag.", img: "assets/images/crimps-tight-curl.jpg" }
];

window.PRODUCTS = [
  // NOTE: A few products below reuse an existing texture photo as a stand-in (no unique
  // shot available yet). Swap these for real product photography before launch for the
  // most professional result — see assets/images/ for the current photo library.
  // ---- Bodywave ----
  { id: "p1", rating: 4.8, reviews: 50, name: "Bodywave Wig", cat: "bodywave", tag: "Bestie favourite", meta: "Soft bodywave • everyday wear", price: 699, wasPrice: 850, type: "wave", img: "assets/images/bodywave-black-glossy.jpg", inStock: true,
    desc: "Our most-loved everyday wig. Soft, bouncy bodywave curls that move naturally and hold their shape wash after wash — an easy grab-and-go look for work, class or weekends." },
  { id: "p2", rating: 4.8, reviews: 36, name: "Bodywave Bundle", cat: "bodywave", tag: "Bundle", meta: "18\" • soft wave • reusable", price: 499, type: "wave", img: "assets/images/bodywave-black-glossy.jpg", inStock: true,
    desc: "A reusable 18\" bodywave bundle for customers who want to install their own unit. Soft wave pattern that blends easily and can be restyled between wears." },
  { id: "p13", rating: 4.7, reviews: 64, name: "Honey Brown Bodywave Wig", cat: "bodywave", tag: "Colour pop", meta: "Balayage highlights • body wave", price: 899, wasPrice: 1020, type: "wave", img: "assets/images/bodywave-honey-highlight.jpg", inStock: true,
    desc: "Warm balayage highlights melt into a soft bodywave pattern for a sun-kissed, dimensional finish — perfect if you want colour without a full commitment." },
  { id: "p14", rating: 4.7, reviews: 92, name: "Chocolate Bodywave Wig", cat: "bodywave", tag: "Rich tone", meta: "Deep brown • soft curl ends", price: 749, type: "wave", img: "assets/images/bodywave-chocolate-curl.jpg", inStock: true,
    desc: "A rich, deep chocolate brown with gently curled ends. Flattering on every skin tone and easy to dress up or down." },

  // ---- Crimps ----
  { id: "p3", rating: 4.7, reviews: 120, name: "Crimps Wig", cat: "crimps", tag: "Texture", meta: "Crimped finish • statement look", price: 649, type: "curl", img: "assets/images/crimps-deep-curl.jpg", inStock: true,
    desc: "Full, crimped texture with real volume. A statement piece for anyone who wants their hair to do the talking." },
  { id: "p4", rating: 4.6, reviews: 36, name: "Crimps Bundle", cat: "crimps", tag: "Bundle", meta: "18\" • textured finish", price: 399, type: "curl", img: "assets/images/crimps-deep-curl.jpg", inStock: true,
    desc: "An 18\" textured crimp bundle, ideal for adding volume and personality to your own install." },
  { id: "p15", rating: 4.8, reviews: 92, name: "Tight Curl Crimps Wig", cat: "crimps", tag: "Full volume", meta: "Tight curl crimp • lace front", price: 799, type: "curl", img: "assets/images/crimps-tight-curl.jpg", inStock: true,
    desc: "Tightly crimped curls on a pre-plucked lace front for a naturally full, voluminous finish that lasts." },

  // ---- Futura Fibre ----
  { id: "p5", rating: 4.6, reviews: 36, name: "Futura Fibre Wig", cat: "futura", tag: "Heat-friendly", meta: "Fibre wig • check heat label", price: 549, type: "straight", img: "assets/images/futura-bangs.jpg", inStock: true,
    desc: "A budget-smart fibre wig with a soft, natural-looking finish. Always check the heat label before styling with hot tools." },
  { id: "p6", rating: 4.6, reviews: 36, name: "Futura Fibre Long", cat: "futura", tag: "Budget pick", meta: "24\" • lightweight fibre", price: 599, type: "straight", img: "assets/images/straight-classic-black.jpg", inStock: true,
    desc: "24 inches of lightweight fibre length, made to give you a dramatic look without a dramatic price tag." },
  { id: "p17", rating: 4.8, reviews: 64, name: "Futura Fibre Wig with Bangs", cat: "futura", tag: "New", meta: "Curtain bangs • heat-resistant fibre", price: 649, type: "straight", img: "assets/images/futura-bangs.jpg", inStock: true,
    desc: "Soft curtain bangs frame the face beautifully on this heat-resistant fibre wig — a fresh, low-maintenance everyday look." },

  // ---- Headband Wigs ----
  { id: "p7", rating: 4.9, reviews: 134, name: "Headband Wig", cat: "headband", tag: "Easy wear", meta: "Glueless • beginner friendly", price: 499, type: "wave", img: "assets/images/headband-straight.jpg", inStock: true,
    desc: "No glue, no gel, no fuss. Slip this on and go — the attached headband keeps everything secure and beginner friendly." },
  { id: "p18", rating: 4.8, reviews: 106, name: "Curly Headband Wig", cat: "headband", tag: "Curly", meta: "Effortless install • curly texture", price: 599, type: "curl", img: "assets/images/headband-curly.jpg", inStock: true,
    desc: "Bouncy curls on an effortless headband install. Ready to wear in minutes, no lace melting required." },

  // ---- Human Hair Blends ----
  { id: "p8", rating: 4.8, reviews: 120, name: "Human Hair Blend", cat: "humanblend", tag: "Blend", meta: "Natural feel • affordable blend", price: 899, type: "wave", img: "assets/images/humanblend-sleek-straight.jpg", inStock: true,
    desc: "A blend of human hair for a softer, more natural feel and movement — without the price tag of a 100% human hair unit." },
  { id: "p19", rating: 5.0, reviews: 106, name: "Curly Human Hair Blend Wig", cat: "humanblend", tag: "Double drawn", meta: "Full curls • natural density", price: 949, type: "curl", img: "assets/images/humanblend-curly.jpg", inStock: true,
    desc: "Double-drawn for extra fullness from root to tip. Natural density and bounce in a soft, defined curl." },

  // ---- Straight Wigs ----
  { id: "p9", rating: 4.9, reviews: 106, name: "Straight Wig", cat: "straight", tag: "Classic", meta: "Sleek finish • everyday glam", price: 749, wasPrice: 830, type: "straight", img: "assets/images/straight-soft-glam.jpg", inStock: true,
    desc: "A clean, sleek straight finish that works for every day and every occasion. Effortless glam, zero styling drama." },
  { id: "p20", rating: 4.8, reviews: 120, name: "Straight Wig — Waist Length", cat: "straight", tag: "Long length", meta: "Sleek • glass-hair finish", price: 899, wasPrice: 1060, type: "straight", img: "assets/images/straight-sleek-long.jpg", inStock: true,
    desc: "Dramatic waist-length straight hair with a glossy, glass-hair finish for maximum impact." },
  { id: "p21", rating: 4.8, reviews: 64, name: "Straight Wig — Classic Black", cat: "straight", tag: "Everyday", meta: "Silky straight • natural black", price: 699, type: "straight", img: "assets/images/straight-classic-black.jpg", inStock: true,
    desc: "Silky, natural black straight hair that blends seamlessly for an undetectable, everyday-wearable look." },
  { id: "p22", rating: 5.0, reviews: 120, name: "Straight Wig — Chestnut Brown", cat: "straight", tag: "Colour pick", meta: "Rich chestnut tone • sleek finish", price: 949, type: "straight", img: "assets/images/straight-chestnut-brown.jpg", inStock: true,
    desc: "A rich chestnut brown tone in a sleek, straight finish — warm, wearable colour that suits most complexions." },

  // ---- Full Frontals ----
  { id: "p10", rating: 4.9, reviews: 22, name: "4x4 Full Frontal", cat: "frontal", tag: "Install ready", meta: "4x4 lace • styling options", price: 699, type: "straight", img: "assets/images/humanblend-sleek-straight.jpg", inStock: true,
    desc: "A 4x4 lace frontal built for versatile parting and styling. Install-ready for your next unit." },
  { id: "p24", rating: 4.8, reviews: 28, name: "13x4 Lace Frontal Wig", cat: "frontal", tag: "Trending", meta: "13x4 lace • pre-plucked • wavy", price: 899, type: "wave", img: "assets/images/glueless-glossy-waves.jpg", inStock: true,
    desc: "A wider 13x4 lace frontal for more parting freedom, pre-plucked with soft, glossy waves for a natural hairline." },
  { id: "p25", rating: 4.7, reviews: 19, name: "5x5 Closure Wig", cat: "frontal", tag: "Natural part", meta: "5x5 closure • sleek straight", price: 799, type: "straight", img: "assets/images/straight-soft-glam.jpg", inStock: true,
    desc: "A 5x5 closure piece for a natural-looking part in any direction, finished sleek and straight for effortless everyday wear." },

  // ---- Glueless Wigs ----
  { id: "p11", rating: 4.7, reviews: 106, name: "Glueless Bob Wig", cat: "glueless", tag: "No glue", meta: "Short bob • easy wear", price: 649, type: "straight", img: "assets/images/glueless-bob-sleek.jpg", inStock: true,
    desc: "A sleek, short bob built for glueless, easy wear. Pop it on for an instant chic finish with no adhesive needed." },
  { id: "p16", rating: 4.7, reviews: 36, name: "Glueless Wig — Bouncy Waves", cat: "glueless", tag: "Best seller", meta: "13x4 lace • glossy waves • pre-plucked", price: 899, wasPrice: 1060, type: "wave", img: "assets/images/glueless-glossy-waves.jpg", inStock: true,
    desc: "Our best-selling glueless unit. Pre-plucked 13x4 lace with glossy, bouncy waves that look salon-fresh straight out of the box." },
  { id: "p23", rating: 4.9, reviews: 50, name: "Glueless Butterfly Bob Wig", cat: "glueless", tag: "Trending", meta: "Layered butterfly cut • soft bangs", price: 749, wasPrice: 940, type: "straight", img: "assets/images/glueless-butterfly-bob.jpg", inStock: true,
    desc: "The trending layered butterfly cut with soft, face-framing bangs — glueless and ready to wear the moment it arrives." },

  // ---- Latisha Dupe ----
  { id: "p12", rating: 5.0, reviews: 64, name: "Latisha Dupe Wig", cat: "dupe", tag: "Inspired style", meta: "Budget-friendly statement wig", price: 799, type: "curl", img: "assets/images/crimps-tight-curl.jpg", inStock: true,
    desc: "The look you've been eyeing, at a RIANA-friendly price. A budget inspired statement wig that doesn't compromise on impact." },
  { id: "p26", rating: 4.8, reviews: 41, name: "Latisha Dupe Bob", cat: "dupe", tag: "Short & bold", meta: "Chin-length • glueless install", price: 699, type: "straight", img: "assets/images/glueless-bob-sleek.jpg", inStock: true,
    desc: "The trending bob look, dupe'd at a friendlier price. Sleek, chin-length and glueless for a quick, chic install." },
  { id: "p27", rating: 4.7, reviews: 24, name: "Latisha Dupe Bundle", cat: "dupe", tag: "DIY install", meta: "18\" • reusable • textured", price: 549, type: "curl", img: "assets/images/crimps-deep-curl.jpg", inStock: true,
    desc: "A textured 18\" bundle for customers who want to install the dupe look themselves, at an even friendlier price point." }
];
